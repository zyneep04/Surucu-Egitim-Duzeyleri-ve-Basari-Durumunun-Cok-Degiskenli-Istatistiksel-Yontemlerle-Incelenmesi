# Surucu-Egitim-Duzeyleri-ve-Basari-Durumunun-Cok-Degiskenli-Istatistiksel-Yontemlerle-Incelenmesi
#İçindekiler 

#VERİ TANIMLAMA 3	 

#VERİ ANALİZİ  5 

#Sayısal Değişkenler 5 

#Kategorik Değişkenler 8 

#Korelasyon Matrisi İncelemesi 9 

#MANOVA 10 

#Manova Varsayımlarının Kontrolü 10 

#Tek Yönlü MANOVA 13 

#Çift Yönlü MANOVA 21 

#Manova Genel Değerlendirme ve Sonuç 28 

#Temel Bileşenler Analizi ve Faktör Analizi 29 

#Temel Bileşenler Analizi 29 

#Faktör Analizi 36 

#Temel Bileşenler Analizi ve Faktör Analizi Genel Değerlendirme ve Sonuç 39 

#Diskriminant Analizi 40 

#Diskriminant Analizi Varsayımlarının Kontrolü 40 

#Lineer Diskriminant Analizi – Binary 43 

#Lineer Diskriminant Analizi – Binary (Stepwise) 50 

#Lineer Diskriminant Analizi – Binary  Genel Değerlendirme ve Sonuç 53 

#Lineer Diskriminant Analizi – Multi Group 53 

#Lineer Diskriminant Analizi – Multi Group (Stepwise) 64 

#Lineer Diskriminant Analizi – Multi Group  Genel Değerlendirme ve Sonuç 67 

#Lojistik Regresyon Analizi 68 

#Lojistik Regresyon Analizi - Binary 70 

#Lojistik Regresyon Analizi – Binary (Stepwise) 76 

#Lojistik Regresyon Analizi – Multinominal 77 

#Lojistik Regresyon Analizi Genel Değerlendirme ve Sonuç 80 

#Kümeleme Analizi 81 

#Hiyerarşik Kümeleme 83 

#Hiyerarşik Olmayan Kümeleme (K-Means Kümeleme Yöntemi) 85 

#Kümeleme Genel Değerlendirme ve Sonuç 89 

#Kaynakça
